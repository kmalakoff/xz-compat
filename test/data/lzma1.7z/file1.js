// LZMA1 fixture file 1
