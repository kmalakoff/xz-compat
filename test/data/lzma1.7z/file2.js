// LZMA1 fixture file 2
